# Ask user for input
print "Please enter your name: "

# Assign the input value to a variable
# Your program waits for the user to hit enter
name = gets.chomp

# ... then continues to this line
puts "Hello " + name