# Ask the user for input on the weather!

# Use chomp to get the user input

# Instead of telling your program if it's cold,
# you can input the temperature and let it decide what to do.

# if the weather is greater than or equal to 25 degrees

# the weather is less than 25 degrees AND greater than 15 degrees
