# Require the csv library
require 'csv'

# Open the 'no-emissions.csv' with a foreach loop

# Loop through each of the rows

    # Compare the integer in the second entry (row[1]) with the integer in the third entry (row[2]) of the current row

        # Print "The difference in emissions between 2002 and 2012 for [COUNTRY] is [NUMBER] kilotonnes!"
