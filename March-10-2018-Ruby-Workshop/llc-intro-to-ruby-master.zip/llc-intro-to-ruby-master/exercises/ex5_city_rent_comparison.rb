# Require the csv library
require 'csv'

# Open the 'rent-data.csv' with a foreach loop
# for now it is okay for them to be blank

# default variable for highest rent

  # Loop through each of the rows
    # Compare cities using or/and statements to narrow down the data

# Print info about the city with the highest rent